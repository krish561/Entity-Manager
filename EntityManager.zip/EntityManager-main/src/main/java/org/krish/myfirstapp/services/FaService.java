package org.krish.myfirstapp.services;

import java.util.List;
import org.krish.myfirstapp.model.Fa;

public interface FaService {

    String createEmployee(Fa employee);
    List<Fa> readEmployees();
    boolean deleteEmployee(Long id);
    String updateEmployee(Long id, Fa employee);
    Fa readEmployees(Long id);
    List<Fa> searchEmployees(String name, String email, String phone);
}