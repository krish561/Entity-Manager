package org.krish.myfirstapp.controller;

import java.util.List;

import org.krish.myfirstapp.exception.ResourceNotFoundException;
import org.krish.myfirstapp.model.Fa;
import org.krish.myfirstapp.services.FaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins = "http://localhost:5173")
public class FaController {
    
    private static final Logger logger = LoggerFactory.getLogger(FaController.class);

    @Autowired
    private FaService employeeService;

    @GetMapping("/employees")
    public ResponseEntity<List<Fa>> getAllEmployees() {
        logger.info("Fetching all employees");
        return ResponseEntity.ok(employeeService.readEmployees());
    }

    @GetMapping("/employees/{id}")
    public ResponseEntity<Fa> getEmployeeById(@PathVariable Long id) {
        logger.info("Fetching employee with ID: {}", id);
        return ResponseEntity.ok(employeeService.readEmployees(id));
    }

    @GetMapping("/employees/search")
    public ResponseEntity<List<Fa>> searchEmployees(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String phone) {
        logger.info("Searching employees with filters - name: {}, email: {}, phone: {}", name, email, phone);
        return ResponseEntity.ok(employeeService.searchEmployees(name, email, phone));
    }

    @PostMapping("/employees")
    public ResponseEntity<String> createEmployee(@RequestBody Fa employee) {
        logger.info("Creating new employee: {}", employee);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(employeeService.createEmployee(employee));
    }

    @DeleteMapping("/employees/{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable Long id) {
        logger.info("Deleting employee with ID: {}", id);
        if (employeeService.deleteEmployee(id)) {
            return ResponseEntity.ok("Employee deleted successfully");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Employee not found");
    }

    @PutMapping("/employees/{id}")
    public ResponseEntity<String> updateEmployee(@PathVariable Long id, @RequestBody Fa employee) {
        logger.info("Updating employee with ID: {}", id);
        return ResponseEntity.ok(employeeService.updateEmployee(id, employee));
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<String> handleResourceNotFoundException(ResourceNotFoundException ex) {
        logger.error("Resource not found: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGeneralException(Exception ex) {
        logger.error("An error occurred: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("An unexpected error occurred");
    }
}