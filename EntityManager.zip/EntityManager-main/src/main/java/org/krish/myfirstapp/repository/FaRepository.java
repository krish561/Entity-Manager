package org.krish.myfirstapp.repository;

import java.util.List;
import org.krish.myfirstapp.entity.FaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
// import java.util.List;

@Repository
public interface FaRepository extends JpaRepository<FaEntity, Long> {
    List<FaEntity> findByActiveTrue();
    List<FaEntity> findByNameContainingIgnoreCase(String name);
    List<FaEntity> findByEmailContainingIgnoreCase(String email);
    List<FaEntity> findByPhoneContaining(String phone);
    //cutom method
    //List<EmployeeEntity> findByName(String name);
    //save, delete, findById , findAll
}
