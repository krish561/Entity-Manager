package org.krish.myfirstapp.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.krish.myfirstapp.entity.FaEntity;
import org.krish.myfirstapp.exception.ResourceNotFoundException;
import org.krish.myfirstapp.model.Fa;
import org.krish.myfirstapp.repository.FaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class FaServiceImpl implements FaService {

    private static final Logger logger = LoggerFactory.getLogger(FaServiceImpl.class);

    @Autowired
    private FaRepository employeeRepository;

    //List<Employee> employees= new ArrayList<>();

    @Override
    public String createEmployee(Fa employee) {
        logger.info("Creating new employee: {}", employee);
        FaEntity employeeEntity = new FaEntity();
        BeanUtils.copyProperties(employee, employeeEntity);
        employeeEntity.setActive(true);
        
        try {
            employeeRepository.save(employeeEntity);
            logger.info("Employee created successfully with ID: {}", employeeEntity.getId());
            return "Saved Successfully";
        } catch (Exception e) {
            logger.error("Error creating employee: {}", e.getMessage());
            throw new RuntimeException("Failed to create employee", e);
        }
    }

    @Override
    public Fa readEmployees(Long id) {
        logger.info("Fetching employee with ID: {}", id);
        Optional<FaEntity> employeeEntity = employeeRepository.findById(id);
        
        if (employeeEntity.isEmpty() || !employeeEntity.get().isActive()) {
            logger.warn("Employee not found with ID: {}", id);
            throw new ResourceNotFoundException("Employee not found with id: " + id);
        }
        
        Fa employee = new Fa();
        BeanUtils.copyProperties(employeeEntity.get(), employee);
        return employee;
    }

    @Override
    public List<Fa> readEmployees() {
        logger.info("Fetching all active employees");
        List<FaEntity> employeesList = employeeRepository.findByActiveTrue();
        List<Fa> employees = new ArrayList<>();
        
        for (FaEntity employeeEntity : employeesList) {
            Fa emp = new Fa();
            BeanUtils.copyProperties(employeeEntity, emp);
            employees.add(emp);
        }
        
        logger.info("Found {} active employees", employees.size());
        return employees;
    }

    @Override
    public boolean deleteEmployee(Long id) {
        logger.info("Deleting employee with ID: {}", id);
        Optional<FaEntity> employee = employeeRepository.findById(id);
        
        if (employee.isEmpty()) {
            logger.warn("Employee not found for deletion with ID: {}", id);
            throw new ResourceNotFoundException("Employee not found with id: " + id);
        }
        
        try {
            // Soft delete by setting active to false
            FaEntity emp = employee.get();
            emp.setActive(false);
            employeeRepository.save(emp);
            logger.info("Employee soft deleted successfully with ID: {}", id);
            return true;
        } catch (Exception e) {
            logger.error("Error deleting employee: {}", e.getMessage());
            throw new RuntimeException("Failed to delete employee", e);
        }
    }

    @Override
    public String updateEmployee(Long id, Fa employee) {
        logger.info("Updating employee with ID: {}", id);
        Optional<FaEntity> existingEmployeeOpt = employeeRepository.findById(id);
        
        if (existingEmployeeOpt.isEmpty()) {
            logger.warn("Employee not found for update with ID: {}", id);
            throw new ResourceNotFoundException("Employee not found with id: " + id);
        }
        
        try {
            FaEntity existingEmployee = existingEmployeeOpt.get();
            existingEmployee.setEmail(employee.getEmail());
            existingEmployee.setName(employee.getName());
            existingEmployee.setPhone(employee.getPhone());
            
            employeeRepository.save(existingEmployee);
            logger.info("Employee updated successfully with ID: {}", id);
            return "Update Successfully";
        } catch (Exception e) {
            logger.error("Error updating employee: {}", e.getMessage());
            throw new RuntimeException("Failed to update employee", e);
        }
    }

    @Override
    public List<Fa> searchEmployees(String name, String email, String phone) {
        logger.info("Searching employees with filters - name: {}, email: {}, phone: {}", name, email, phone);
        
        List<FaEntity> results = new ArrayList<>();
        
        if (name != null && !name.isEmpty()) {
            results.addAll(employeeRepository.findByNameContainingIgnoreCase(name));
        }
        if (email != null && !email.isEmpty()) {
            results.addAll(employeeRepository.findByEmailContainingIgnoreCase(email));
        }
        if (phone != null && !phone.isEmpty()) {
            results.addAll(employeeRepository.findByPhoneContaining(phone));
        }
        
        // Remove duplicates and filter active employees
        List<FaEntity> uniqueResults = results.stream()
                .distinct()
                .filter(FaEntity::isActive)
                .collect(Collectors.toList());
        
        // Convert to DTOs
        List<Fa> employees = new ArrayList<>();
        for (FaEntity entity : uniqueResults) {
            Fa emp = new Fa();
            BeanUtils.copyProperties(entity, emp);
            employees.add(emp);
        }
        
        logger.info("Found {} matching employees", employees.size());
        return employees;
    }

    

   
}
