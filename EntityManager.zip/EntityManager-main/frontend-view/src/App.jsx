import { useState } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './App.css'
import Navbar from './components/Navbar'
import EmployeeList from './components/EmployeeList'
import AddEmployee from './components/AddEmployee'
import UpdateEmployee from './components/UpdateEmployee'

function App() {
  // eslint-disable-next-line no-empty-pattern
  const [] = useState(0)

  return (
    <BrowserRouter>
      <div className="App flex flex-col min-h-screen">
        <Navbar />
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={<EmployeeList />} />
            <Route path="/add-employee" element={<AddEmployee />}/>
            <Route path="/edit-employee/:id" element={<UpdateEmployee/>}/>
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;