import {} from 'react';

const Navbar = () => {
    return (
        // Navbar
      <div className="bg-teal-300 h-[5vh] flex items-center justify-between px-4 overflow-hidden">
        <h1 className=" font-bold text-green-900 whitespace-nowrap overflow-hidden text-ellipsis">
          Employee Service
        </h1>
        {/* Links */}
        <div className="flex space-x-4  font-bold">
          <a className='hover:text-blue-400' href='/'>Home</a>
          <a className='hover:text-blue-400' href='/'>Profile</a>
          <a className='hover:text-blue-400' href='/'>Logout</a>
        </div>
      </div>
    );
};

export default Navbar;