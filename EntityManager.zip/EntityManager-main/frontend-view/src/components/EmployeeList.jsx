import {useState} from 'react'
import {useNavigate} from 'react-router-dom'
import {useEffect} from 'react'
import EmployeeService from '../service/EmployeeService'


const EmployeeList = () => {
  const [loading, setLoading] = useState(true);

  const [employee, setEmployees] = useState(null);
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await EmployeeService.getEmployees();
        setEmployees(response.data);
      } catch (error) {
        console.log(error);
      }
      setLoading(false);
    };
    fetchData();
  }, []);


const deleteEmployee = async (e, id) => {
  e.preventDefault();
  try {
    await EmployeeService.deleteEmployeeById(id);
    if (employee) {
      setEmployees((prevElement) => {
        return prevElement.filter((employee) => employee.id !== id);
      });
    }
  } catch (error) {
    console.log(error);
  }
};

  const navigate = useNavigate();
  return (
        <div className="container flex flex-col flex-grow p-4">
          <div>
            {/* Button */}
            <button 
            onClick={() => navigate('/add-employee')}
            className='bg-slate-600 hover:bg-slate-800 text-white font-bold py-2 px-4 rounded'>
              Add Employee
            </button>
          </div>
          <div className="shadow mt-4 overflow-x-auto">
            <table className='border border-black w-full'>
              <thead className='bg-rose-400 text-white'> 
                <tr>
                  <th className='px-6 py-3 uppercase tracking-wide'>Employee Name</th>
                  <th className='px-6 py-3 uppercase tracking-wide'>Employee Phone</th>
                  <th className='px-6 py-3 uppercase tracking-wide'>Employee Email</th>
                  <th className='px-6 py-3 uppercase tracking-wide'>Actions</th>
                </tr>
              </thead>
              {!loading && (
              <tbody>
                {employee && employee.map((employee) => (
                <tr key={employee.id} className='hover:bg-gray-100 hover:text-black'>
                  <td className='text-left px-6 py-4 whitespace-nowrap'>{employee.name}</td>
                  <td className='text-left px-6 py-4 whitespace-nowrap'>{employee.phone}</td>
                  <td className='text-left px-6 py-4 whitespace-nowrap'>{employee.email}</td>
                  <td className='text-left px-6 py-4 whitespace-nowrap'>
                    <a 
                    onClick={() => navigate(`/edit-employee/${employee.id}`)}
                    className="text-blue-500 hover:text-blue-700 mr-2 hover:cursor-pointer">Edit</a>
                    <a 
                    onClick={(e) => deleteEmployee(e,employee.id)}
                    className="text-red-500 hover:text-red-700  hover:cursor-pointer">Delete</a>
                  </td>
                </tr>
                ))}
              </tbody>
              )}
            </table>
          </div>
        </div>
      );
    }; 
export default EmployeeList