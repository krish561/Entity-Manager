import 'react'
import { useNavigate } from 'react-router-dom'
import { useState } from 'react'
import EmployeeService from '../service/EmployeeService'

const AddEmployee = () => {
  const navigate = useNavigate();
  const [employee, setEmployee] = useState({
    id:"",
    name: '',
    phone: '',
    email: ''
  });
  const reset = (e) => {
    e.preventDefault();
    setEmployee({
      id:"",
      name: '',
      phone: '',
      email: ''
    });
  }
  const handleChange = (e) => {
    const value = e.target.value;
    setEmployee({
      ...employee,
      [e.target.name]: e.target.value
    });
  }
  const saveEmployee = (e) => {
    e.preventDefault();
    EmployeeService.saveEmployee(employee)
    .then(res => {
      console.log("saved",res);
      navigate('/');
    })
    .catch(err => {
      console.log(err);
    });
  }
  return (
    <div className='max-w-xl mx-40 bg-slate-600 my-20 rounded-3xl shadow py-4 px-8'>
      <div className='text-center text-4xl font-bold py-4 px-8'>
        <p>Add Employee</p>
        </div>
        <div className='mx-10 my-2'>
          <input 
          type='text'
          name='name'
          value={employee.name}
          onChange={(e) => handleChange(e)}
          placeholder='Name' className='w-full border-2 border-gray-300 p-2 rounded mb-2' />
          <input 
          name='phone'
          type='number'
          value={employee.phone}
          onChange={(e) => handleChange(e)}
          placeholder='Phone' className='w-full border-2 border-gray-300 p-2 rounded mb-2' />
          <input 
          type='email'
          name='email'
          value={employee.email}
          onChange={(e) => handleChange(e)}
          placeholder='Email' className='w-full border-2 border-gray-300 p-2 rounded mb-2' />
          </div>
          <div className=' flex-auto space-x-8 text-center'>
            <button 
            onClick={saveEmployee}
            className='bg-green-500 hover:bg-green-700 text-white px-6 py-2 rounded-'>Save</button>
            <button 
            onClick={reset}
            className='bg-blue-500 hover:bg-blue-700 text-white px-6 py-2 rounded'>Clear</button>
            <button 
            onClick={() => navigate('/')}
            className='bg-red-500 hover:bg-red-700 text-white px-6 py-2 rounded'>Cancel</button>
            </div>
    </div>
  )
}

export default AddEmployee